import Vue from 'vue'
import * as TastyBurgerButton from 'vue-tasty-burgers';

Vue.use(TastyBurgerButton);
