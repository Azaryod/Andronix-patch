<template>
  <div class="h-full bg-background">
    <div class="px-12 mt-12">
      <div class="text-white">
        <h1 class="font-extrabold text-3xl md:text-4xl lg:text-5xl mb-8">
          Refund Policy
        </h1>
        <div class="text-gray-400">
          <p class="text-gray-400 prose md:prose-lg">
            Andronix offers digital purchases that include Andronix Premium, Andronix Modded OS and much more. We
            strictly follow the aforementioned refund policy and the deviation from the same entirely depends upon our
            discretion.
            <br>
            <br>
            If your purchase qualifies for the refund, it will be a no-questions asked refund.
          </p>
          <br>
          <p class="text-2xl text-white mt-4 mb-3 font-bold">
            Andronix Premium
          </p>
          <p class="text-red-400 prose font-bold md:prose-lg">We don't offer refunds on Andronix Premium when bought from our app.</p>
          <p class="text-gray-400 prose md:prose-lg">
            Please read carefully
            what does it
            offer and then make a
            purchase.</p>
          <br>
          <p class="text-green-400 prose font-bold md:prose-lg">We do offer refunds on Andronix Premium when bought from our website.</p>
          <br>
          <br>
          <p class="text-2xl text-white mt-4 mb-3 font-bold">
            Andronix Modded OS
          </p>
          <p class="text-green-400 prose font-bold md:prose-lg">We do offer refunds on Andronix
            Modded OS</p>
          <p class="text-gray-400 prose md:prose-lg">
            We have no-questions asked refund policy for Modded OS if your purchase satisfies the following condition</p>
          <div class="text-gray-400 font-bold mt-4 prose md:prose-lg">
            <p>Your purchase is made within 3 days of raising the refund request. This is counted from the local time
              of the purchase.</p>
          </div>
          <br>
          <br>
          <p class="prose-sm font-bold text-red-400">We don't entertain swapping requests for Modded OS,
            unless the original one is not properly functioning.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'refund-policy'
}
</script>

<style scoped>

</style>
