<template>
  <div>


  </div>
</template>

<script>
export default {
  name: 'Feature'
}
</script>

<style scoped>

</style>
